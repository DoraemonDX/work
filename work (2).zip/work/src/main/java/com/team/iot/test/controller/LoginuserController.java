package com.team.iot.test.controller;


import com.team.iot.test.Mapper.LoginuserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody
public class LoginuserController {

    @Autowired
    private LoginuserMapper loginusermapper;

    @RequestMapping("/addLoginuser")
    public String addLofinuser(LoginuserMapper loginuserMapper){
        return loginusermapper.addLoginuser(loginuserMapper)+"";
    }

    @RequestMapping("/deleteLoginuser")
    public String deleteLofinuser(LoginuserMapper loginuserMapper){
        return loginusermapper.deleteLoginuser(loginuserMapper)+"";
    }

    @RequestMapping("/updateLoginuser")
    public String updateLofinuser(LoginuserMapper loginuserMapper){
        return loginusermapper.updateLoginuser(loginuserMapper)+"";
    }

    @RequestMapping("/validateLogon")
    public String validateLogon(LoginuserMapper loginuserMapper){
        return loginusermapper.validateLogon(loginuserMapper)+"";
    }

}

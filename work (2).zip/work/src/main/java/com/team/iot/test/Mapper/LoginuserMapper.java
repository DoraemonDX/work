package com.team.iot.test.Mapper;


import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface LoginuserMapper {
    public int addLoginuser(LoginuserMapper loginuserMapper);
    public int deleteLoginuser(LoginuserMapper loginuserMapper);
    public int updateLoginuser(LoginuserMapper loginuserMapper);
    public LoginuserMapper validateLogon(LoginuserMapper loginuserMapper);
}
